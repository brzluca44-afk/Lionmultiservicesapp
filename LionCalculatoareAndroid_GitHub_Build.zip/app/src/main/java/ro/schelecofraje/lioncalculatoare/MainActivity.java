package ro.schelecofraje.lioncalculatoare;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.content.Intent;
import android.net.Uri;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;

public class MainActivity extends Activity {

    private WebView webView;
    private ProgressBar progressBar;

    private final String URL_SCHELA = "https://schele-cofraje.ro/schele/";
    private final String URL_PLANSEU = "https://schele-cofraje.ro/planseu/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private void showHome() {
        webView = null;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(34, 34, 34, 34);
        root.setBackgroundColor(Color.parseColor("#fff7ef"));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("logo_lion", "drawable", getPackageName()));
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);

        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                360
        );
        logoParams.setMargins(0, 0, 0, 18);
        logo.setLayoutParams(logoParams);

        TextView title = new TextView(this);
        title.setText("Calculează prețul");
        title.setTextSize(28);
        title.setTextColor(Color.parseColor("#111111"));
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, 28);
        title.setTypeface(null, 1);

        Button scheleBtn = makeButton("Schele");
        Button planseuBtn = makeButton("Cofraje Planșeu");

        scheleBtn.setOnClickListener(v -> openWeb(URL_SCHELA));
        planseuBtn.setOnClickListener(v -> openWeb(URL_PLANSEU));

        root.addView(logo);
        root.addView(title);
        root.addView(scheleBtn);
        root.addView(planseuBtn);

        setContentView(root);
    }

    private Button makeButton(String text) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(22);
        btn.setTextColor(Color.WHITE);
        btn.setAllCaps(false);
        btn.setBackgroundColor(Color.parseColor("#e85d04"));
        btn.setTypeface(null, 1);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                150
        );
        params.setMargins(0, 14, 0, 14);
        btn.setLayoutParams(params);

        return btn;
    }

    private void openWeb(String url) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);

        Button backBtn = new Button(this);
        backBtn.setText("⬅ Înapoi");
        backBtn.setTextSize(18);
        backBtn.setTextColor(Color.WHITE);
        backBtn.setAllCaps(false);
        backBtn.setBackgroundColor(Color.parseColor("#111111"));
        backBtn.setOnClickListener(v -> showHome());

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("tel:") || url.startsWith("https://wa.me/") || url.startsWith("whatsapp://")) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    } catch (Exception ignored) {}
                    return true;
                }

                if (url.equals("https://schele-cofraje.ro") || url.equals("https://schele-cofraje.ro/")) {
                    showHome();
                    return true;
                }

                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int progress) {
                progressBar.setProgress(progress);
                progressBar.setVisibility(progress == 100 ? View.GONE : View.VISIBLE);
            }
        });

        layout.addView(backBtn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 110
        ));
        layout.addView(progressBar, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 8
        ));
        layout.addView(webView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1
        ));

        setContentView(layout);
        webView.loadUrl(url);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else if (webView != null) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }
}
